# Design-Optimisation

This repository is for Design Optimisation Project Assignment 1.

For Assignment 1cpart2, the workflow of the scripts:

cleaner-> liveclean -> pearsoncoef -> scaledregression -> variancebased

Simply run these scripts in order and results should be displayed on matlab prompt.
For Part 1cpart2, simply run the part1cb3 script.

Please keep all the scripts in the same environment.


Excel sheets for Part 1a, 1b and 1d can also be found here.
